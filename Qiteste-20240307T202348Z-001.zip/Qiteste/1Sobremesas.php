<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Qiteste/styles/styles.css">
    <title>Cardápio de Sobremesas</title>

</head>
<body>

<header>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">ApenasUmBar Cardápio</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="1PratosPrincipais.php">Pratos Principais <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="1index.php">Home</a>
            <li class="nav-item">
                <a class="nav-link" href="1Acompanhamentos.php">Acompanhamentos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="1Bebidas.php">Bebidas</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="1Sobremesas.php">Sobremesas</a>
            </li>
        </ul>
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="1LOGI.php">Login</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="1Carrinho.php">Carrinho</a>
            </li>
        </ul>
    </div>
</nav>
</header>

<h2>Cardápio de Sobremesas</h2>

<div class="menu-item">

    <h3><br>Pudim de Leite<br></h3>
        <a><img src="3pudim.png"></a>
        <p><br>Porção de 300g </p>
        <p>Preço: R$ 8.00</p>
        <button type="button" class="btn btn-dark" 
        onclick="addToCart('pudim',8.00)">
        <a href="1Carrinho.php?acao=add&id=Pudim de Leite">Adicionar ao Carrinho</a></button>

    <h3><br>Mousse de Chocolate<br></h3>
        <a><img src="3mousecho.png"></a>
        <p>Taça média <br> de 200g</p>
        <p>Preço: R$ 10,00</p>
        <button type="button" class="btn btn-dark" 
        onclick="addToCart('mousecho',10.00)">
        <a href="1Carrinho.php?acao=add&id=Mousse de Chocolate">Adicionar ao Carrinho</a></button>

    <h3><br>Torta de Limão<br></h3>
        <a><img src="3tortalimao.png"></a>
        <p>Porções de 600g <br></p>
        <p>Preço: R$ 12,00</p>
        <button type="button" class="btn btn-dark" 
        onclick="addToCart('tortalimao',12.00)">
        <a href="1Carrinho.php?acao=add&id=Torta de Limão">Adicionar ao Carrinho</a></button>

    <h3><br>Sorvete de Creme<br></h3>
        <a><img src="3sorvete.png"></a>
        <p>Porção de 400g</p>
        <p>Preço: R$ 6,00</p>
        <button type="button" class="btn btn-dark" 
        onclick="addToCart('sorvete',6.00)">
        <a href="1Carrinho.php?acao=add&id=Sorvete de Creme">Adicionar ao Carrinho</a></button>

    <h3><br>Brigadeiro<br></h3>
        <a><img src="3brigadeiro.png"></a>
        <p>Porção de 180g</p>
        <p>Preço: R$ 1,50</p>
        <button type="button" class="btn btn-dark" 
        onclick="addToCart('brigadeiro',1.50)">
        <a href="1Carrinho.php?acao=add&id=Brigadeiro">Adicionar ao Carrinho</a></button>
        <br>
</div>

<?php
/*$sobremesas = array(
    "Pudim de Leite" => 8.00,
    "Mousse de Chocolate" => 10.00,
    "Torta de Limão" => 12.00,
    "Sorvete de Creme" => 6.00,
    "Brigadeiro" => 1.50,
    "Cheesecake de Morango" => 14.00,
    "Tiramisù" => 15.00,
    "Pavê de Chocolate" => 11.00,
    "Banana Split" => 9.00,
    "Creme Brûlée" => 13.00
);

echo "<ul>";
foreach ($sobremesas as $sobremesa => $preco) {
    echo "<li>$sobremesa - R$ $preco</li>";
}
echo "</ul>";*/
?>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<footer><br>Agradecemos a Preferêcia</footer>
</body>
</html>
